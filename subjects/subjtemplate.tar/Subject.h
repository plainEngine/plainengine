\\#import \\\<MPCore.h\\\>

@interface $SUBJECTNAME : NSObject \\\<MPSubject\\\>
{
\\\\tid \\\<MPAPI\\\> api\\;
}
@end


