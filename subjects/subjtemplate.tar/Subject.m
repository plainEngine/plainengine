\\#import \\\<MPCore.h\\\>
\\#import \\\<$SUBJECTNAME.h\\\>

@implementation $SUBJECTNAME

- initWithString: \\(NSString *\\)aParams
{
\\\\t[super init]\\;
\\\\tapi = nil\\;
\\\\treturn self\\;
}

- init
{
\\\\treturn [self initWithString: @\\"\\"]\\;
}

- \\(void\\) dealloc
{
\\\\tif \\(api\\)
\\\\t{
\\\\t\\\\t[api release]\\;
\\\\t}
\\\\t[super dealloc]\\;
}

- \\(void\\) receiveAPI: \\(id\\\<MPAPI\\\>\\)anAPI
{
\\\\tapi = [anAPI retain]\\;
}

- \\(void\\) start
{

}

- \\(void\\) stop
{

}

- \\(void\\) update
{

}

@end


